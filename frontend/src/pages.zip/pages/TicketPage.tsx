﻿// @ts-check
import React, { useState } from "react";
import styled, { keyframes } from "styled-components";
import RequirePlan from "@/components/security/RequirePlan";

const pulseAnimation = keyframes`
  0% { transform: scale(1); opacity: 1; }
  50% { transform: scale(1.05); opacity: 0.75; }
  100% { transform: scale(1); opacity: 1; }
`;

const PulseBox = styled.div`
  animation: ${pulseAnimation} 2s infinite;
`;

const TicketPage: React.FC = () => {
  const [plan, setPlan] = useState("free");
  const [depart, setDepart] = useState("");
  const [arrivee, setArrivee] = useState("");
  const [date, setDate] = useState("");
  const [heure, setHeure] = useState("");
  const [type, setType] = useState("bus");
  const [iaResponse, setIaResponse] = useState("Suggestion d’itinéraire automatique disponible.");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const data = { depart, arrivee, date, heure, type };
    console.log("🚌 Données soumises :", data);
    alert("🤖 Connexion backend en attente...");
  };

  return (
    <div className="pt-24 pb-32 px-6 bg-white min-h-screen" style={{ fontFamily: "'Inter', sans-serif" }}>
      <h1 className="text-4xl font-bold text-center mb-10 text-gray-800">🎫 Créer un ticket de transport</h1>

      <form onSubmit={handleSubmit} className="max-w-2xl mx-auto bg-white p-8 rounded-lg shadow">
        <label className="block mb-4 font-medium text-gray-700">
          Ville de départ :
          <input
            type="text"
            value={depart}
            onChange={(e) => setDepart(e.target.value)}
            className="w-full mt-2 p-3 border rounded"
            required
          />
        </label>

        <label className="block mb-4 font-medium text-gray-700">
          Ville d’arrivée :
          <input
            type="text"
            value={arrivee}
            onChange={(e) => setArrivee(e.target.value)}
            className="w-full mt-2 p-3 border rounded"
            required
          />
        </label>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <label className="block font-medium text-gray-700">
            Date :
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full mt-2 p-3 border rounded"
              required
            />
          </label>

          <label className="block font-medium text-gray-700">
            Heure :
            <input
              type="time"
              value={heure}
              onChange={(e) => setHeure(e.target.value)}
              className="w-full mt-2 p-3 border rounded"
              required
            />
          </label>
        </div>

        <label className="block mb-6 font-medium text-gray-700">
          Type de transport :
          <select
            value={type}
            onChange={(e) => setType(e.target.value)}
            className="w-full mt-2 p-3 border rounded"
          >
            <option value="bus">🚌 Bus</option>
            <option value="covoiturage">🚗 Covoiturage</option>
            <option value="train">🚆 Train</option>
            <option value="avion">✈️ Avion</option>
          </select>
        </label>

        <button
          type="submit"
          className="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold py-3 rounded"
        >
          ➤ Valider le ticket
        </button>
      </form>

      <PulseBox className="mt-12 bg-gray-50 p-6 max-w-2xl mx-auto rounded-lg shadow">
        <h2 className="text-xl font-bold mb-2 text-gray-800">🤖 Réponse Yukpomnang :</h2>
        <p className="text-gray-700">{iaResponse}</p>

        {plan === "free" && (
          <div className="mt-4 text-red-600 font-semibold">
            <RequirePlan plan="enterprise">
              Fonctionnalités avancées réservées aux comptes Premium
            </RequirePlan>
          </div>
        )}
      </PulseBox>
    </div>
  );
};

export default TicketPage;

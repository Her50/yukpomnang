﻿import React from 'react';
import { Link } from 'react-router-dom';
import RequirePlan from '@/components/security/RequirePlan';
import RequireRole from '@/components/auth/RequireRole';

const NotFound: React.FC = () => {
  return (
    <RequirePlan plan="pro">
      <RequireRole role="user">
        <div className="text-center pt-24">
          <h1 className="text-5xl font-bold mb-4">404</h1>
          <p className="mb-4">Page introuvable</p>
          <Link to="/about" className="text-blue-600 underline">
            Retour à l'accueil
          </Link>
        </div>
      </RequireRole>
    </RequirePlan>
  );
};

export default NotFound;

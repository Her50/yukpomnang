import React, { useEffect } from "react";
import { useSearchParams } from "react-router-dom";

const AcquisitionTracker: React.FC = () => {
  const [params] = useSearchParams();

  useEffect(() => {
    const source = params.get("src") || "unknown";
    fetch("/acquisition/track", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ source })
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.redirect_url) {
          window.location.href = data.redirect_url;
        }
      });
  }, []);

  return <p>Redirection en cours...</p>;
};

export default AcquisitionTracker;

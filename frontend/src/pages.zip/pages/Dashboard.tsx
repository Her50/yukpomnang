﻿import React from "react";
import { Link } from "react-router-dom";
import RequirePlan from "@/components/security/RequirePlan";

const Dashboard: React.FC = () => {
  return (
    <div className="pt-24 px-4 sm:px-4 md:px-4 lg:px-4 xl:px-4 2xl:px-4">
      <h1 className="text-3xl font-bold mb-6">
        📊 Tableau de bord Yukpomnang
      </h1>
      <ul className="space-y-2">
        <RequirePlan plan="enterprise">
          <li>
            <Link to="/dashboard" className="text-blue-600 underline">
              Accès Yukpomnang Premium
            </Link>
          </li>
        </RequirePlan>
      </ul>
    </div>
  );
};

export default Dashboard;

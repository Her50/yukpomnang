﻿// @ts-check
import React from "react";

const ScoringDashboard: React.FC = () => {
  return (
    <div className="p-6">
      <h1 className="text-xl font-bold mb-4">Tableau de scoring IA</h1>
      <p className="text-sm text-gray-600">Comparaison des prestataires, clients et services...</p>
    </div>
  );
};

export default ScoringDashboard;

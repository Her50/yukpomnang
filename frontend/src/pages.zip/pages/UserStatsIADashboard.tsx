﻿// @ts-check
import React from 'react';
import RequirePlan from '@/components/security/RequirePlan'; // ✅ Assurez-vous que ce fichier exporte un `default`

const stats = [
  { label: 'Biens consultés', value: 123, color: '#4CAF50' },
  { label: 'Demandes envoyées', value: 47, color: '#2196F3' },
  { label: 'Matchs Yukpomnang proposés', value: 31, color: '#FF9800' },
  { label: 'Contenus Yukpomnang générés', value: 8, color: '#E91E63' },
];

function StatCard({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div
      style={{
        background: '#fff',
        borderRadius: '12px',
        padding: '20px',
        textAlign: 'center',
        boxShadow: '0 2px 10px rgba(0,0,0,0.08)',
        borderTop: `4px solid ${color}`,
      }}
    >
      <div style={{ fontSize: '40px', fontWeight: 700, color }}>{value}</div>
      <div style={{ marginTop: '8px', fontSize: '16px', fontWeight: 600 }}>{label}</div>
    </div>
  );
}

const UserStatsIADashboard: React.FC = () => {
  return (
    <div className="pt-24 pb-32 px-6 min-h-screen bg-gray-50 font-inter">
      <h1 className="text-3xl font-bold text-center mb-10">📊 Mon tableau Yukpomnang personnalisé</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
        {stats.map((item, index) => (
          <StatCard key={index} label={item.label} value={item.value} color={item.color} />
        ))}
      </div>

      <footer className="text-center text-sm text-gray-500 mt-20 border-t pt-6">
        Yukpomnang — Données simulées © 2025
      </footer>
    </div>
  );
};

export default UserStatsIADashboard;

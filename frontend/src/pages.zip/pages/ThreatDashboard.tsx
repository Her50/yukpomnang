﻿// @ts-check
import React, { useEffect, useState } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

const ThreatDashboard: React.FC = () => {
  const [logs, setLogs] = useState<any[]>([]);

  useEffect(() => {
    fetch("/api/admin/threats")
      .then((res) => res.json())
      .then(setLogs)
      .catch(() => setLogs([]));
  }, []);

  const chartData = logs.map((l) => ({
    date: l.detected_at?.split("T")[0] || "N/A",
    level: l.level === "high" ? 3 : l.level === "medium" ? 2 : 1,
  }));

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-4">🛡️ Menaces IA détectées</h1>

      <ResponsiveContainer width="100%" height={200}>
        <LineChart data={chartData}>
          <XAxis dataKey="date" />
          <YAxis />
          <Tooltip />
          <Line type="monotone" dataKey="level" stroke="#ff0000" />
        </LineChart>
      </ResponsiveContainer>

      <table className="w-full mt-4 text-sm border border-gray-300">
        <thead>
          <tr className="bg-gray-100">
            <th className="p-2 border">User</th>
            <th className="p-2 border">IP</th>
            <th className="p-2 border">Niveau</th>
            <th className="p-2 border">Date</th>
          </tr>
        </thead>
        <tbody>
          {logs.map((l, i) => (
            <tr key={i} className="border-t">
              <td className="p-2 border">{l.user_id}</td>
              <td className="p-2 border">{l.ip}</td>
              <td className="p-2 border">{l.level}</td>
              <td className="p-2 border">{l.detected_at}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ThreatDashboard;

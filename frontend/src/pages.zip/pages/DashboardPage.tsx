﻿import React from 'react';
import RequirePlan from '@/components/security/RequirePlan';
import RequireRole from '@/components/auth/RequireRole';

const DashboardPage: React.FC = () => (
  <RequirePlan plan="pro">
    <RequireRole role="user">
      <div className="pt-24 p-4 sm:pt-32 sm:p-4 md:pt-32 md:p-4 lg:pt-32 lg:p-4 xl:pt-32 xl:p-4 2xl:pt-32 2xl:p-4">
        <h2 className="text-3xl font-bold mb-6">Tableau de bord</h2>
        <p>Composants Yukpomnang et données utilisateur à venir ici...</p>
      </div>
    </RequireRole>
  </RequirePlan>
);

export default DashboardPage;

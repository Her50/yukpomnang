﻿import React, { useEffect, useState } from 'react';

type ApiRoute = {
  path: string;
  method: string;
  file: string;
};

type ApiRegistry = {
  backend_routes: ApiRoute[];
};

const ApiDashboardPage: React.FC = () => {
  const [routes, setRoutes] = useState<ApiRoute[]>([]);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState('');

  const fetchRegistry = async () => {
    setLoading(true);
    try {
      const res = await fetch('/docs/api_registry.json');
      const data: ApiRegistry = await res.json();
      setRoutes(data.backend_routes);
    } catch (err) {
      console.error('Erreur chargement registry:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRegistry();
  }, []);

  const filtered = routes.filter((r) =>
    r.path.toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">🧠 Audit des Routes API</h1>

      <div className="mb-4 flex space-x-4">
        <input
          type="text"
          className="border px-3 py-1 rounded w-64"
          placeholder="Filtrer par path..."
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
        />
        <button
          onClick={fetchRegistry}
          className="bg-blue-600 text-white px-4 py-1 rounded hover:bg-blue-700"
          disabled={loading}
        >
          🔍 Rafraîchir
        </button>
      </div>

      <table className="w-full text-sm border border-gray-300">
        <thead className="bg-gray-100">
          <tr>
            <th className="px-3 py-2 border">📍 Path</th>
            <th className="px-3 py-2 border">⚙️ Méthode</th>
            <th className="px-3 py-2 border">📂 Fichier</th>
            <th className="px-3 py-2 border text-center">🛡️ Protégé</th>
          </tr>
        </thead>
        <tbody>
          {filtered.map((route, i) => (
            <tr key={i} className="border-t">
              <td className="px-3 py-2 border">{route.path}</td>
              <td className="px-3 py-2 border">{route.method}</td>
              <td className="px-3 py-2 border">{route.file.split('/').pop()}</td>
              <td className="px-3 py-2 border text-center">
                {routeProtected(route.file, route.path) ? '✅' : '⚠️'}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

const routeProtected = (file: string, path: string) =>
  file.includes('protected') || path.includes('admin') || path.includes('save');

// ✅ Export par défaut
export default ApiDashboardPage;

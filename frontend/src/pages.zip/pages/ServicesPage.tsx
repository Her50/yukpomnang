// @ts-check
import React from 'react';
import { useNavigate } from 'react-router-dom';
import ProductGrid from '@/components/services/ProductGrid';
import SuggestionsContextuelles from '@/components/services/SuggestionsContextuelles';
import RequirePlan from '@/components/security/RequirePlan';
import RequireRole from '@/components/auth/RequireRole';

const ServicesPage: React.FC = () => {
  const navigate = useNavigate();

  const handleClick = (key: string) => {
    navigate(`/about${key}`);
  };

  return (
    <RequirePlan plan="pro">
      <RequireRole role="user">
        <div className="pt-24 pb-32 bg-white min-h-screen px-6" style={{ fontFamily: "'Inter', sans-serif" }}>
          <h2
            style={{
              fontSize: '36px',
              fontWeight: 700,
              textAlign: 'center',
              marginBottom: '40px',
              color: '#1a1a1a',
            }}
          >
            Nos 3 Produits Phare
          </h2>

          <ProductGrid onClick={handleClick} />

          <div className="mt-12">
            <SuggestionsContextuelles serviceId={1} />
          </div>
        </div>
      </RequireRole>
    </RequirePlan>
  );
};

export default ServicesPage;

import React from "react";

const ForecastPanel: React.FC = () => {
  return (
    <div className="p-4">
      <h2>ForecastPanel</h2>
    </div>
  );
};

export default ForecastPanel;

﻿import React, { useState } from "react";
import axios from "axios";

const SocialContentGenerator: React.FC = () => {
  const [title, setTitle] = useState("");
  const [lang, setLang] = useState("fr");
  const [result, setResult] = useState<null | { url: string; thumbnail: string }>(null);

  const generateContent = async () => {
    try {
      const res = await axios.post("/api/generate-video", { title, lang });
      setResult(res.data);
    } catch (error) {
      console.error("Erreur de génération :", error);
      alert("❌ Échec de la génération de la vidéo");
    }
  };

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">🎥 Générateur de contenu social automatisé</h2>

      <input
        className="border p-2 w-full mb-3"
        placeholder="Titre du service ou contenu"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />

      <select
        className="border p-2 mb-3 w-full"
        value={lang}
        onChange={(e) => setLang(e.target.value)}
      >
        <option value="fr">Français</option>
        <option value="en">English</option>
        <option value="ff">Pulaar</option>
      </select>

      <button
        className="bg-blue-600 text-white p-2 rounded"
        onClick={generateContent}
      >
        Générer Vidéo
      </button>

      {result && (
        <div className="mt-4">
          <p className="text-lg font-semibold">🎬 Vidéo prête :</p>
          <video src={result.url} controls className="w-full my-2" />
          <img src={result.thumbnail} alt="Aperçu" className="w-32 mt-2" />
        </div>
      )}
    </div>
  );
};

export default SocialContentGenerator;

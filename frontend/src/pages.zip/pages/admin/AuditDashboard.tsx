﻿// @ts-check
import React, { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const AuditDashboard: React.FC = () => {
  const [logs, setLogs] = useState<any[]>([]);

  const load = async () => {
    try {
      const res = await fetch("/api/admin/audit-anomalies");
      const json = await res.json();
      setLogs(json.anomalies || []);
    } catch (err) {
      console.error("Erreur lors du chargement des anomalies :", err);
    }
  };

  const exportCSV = () => {
    const csv = logs.map((l, i) => `${i + 1},"${l}"`).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "audit_anomalies.csv";
    a.click();
  };

  useEffect(() => {
    load();
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">🧠 Anomalies détectées par IA</h1>

      <Button onClick={exportCSV} className="mb-4">📤 Export CSV</Button>

      <div className="grid gap-2">
        {logs.length > 0 ? (
          logs.map((log, i) => (
            <Card key={i}>
              <CardContent>{log}</CardContent>
            </Card>
          ))
        ) : (
          <p>Aucune anomalie détectée.</p>
        )}
      </div>
    </div>
  );
};

export default AuditDashboard;

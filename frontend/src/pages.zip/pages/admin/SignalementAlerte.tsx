﻿import React, { useEffect, useState } from 'react';
import axios from 'axios';

type AlerteData = {
  alerte?: boolean;
  erreur?: boolean;
};

function SignalementAlerte() {
  const [alerte, setAlerte] = useState<AlerteData | null>(null);

  useEffect(() => {
    axios
      .get('/api/reports/analyze')
      .then((res) => setAlerte(res.data))
      .catch(() => setAlerte({ erreur: true }));
  }, []);

  return (
    <div className="p-4 bg-white shadow rounded">
      <h2 className="text-xl font-semibold mb-2">🚨 Alerte de Signalements</h2>

      {alerte?.alerte ? (
        <div className="text-red-600 font-bold">
          🚨 Niveau Critique détecté
        </div>
      ) : (
        <div className="text-green-600">
          ✅ Aucun signalement critique.
        </div>
      )}
    </div>
  );
}

export default SignalementAlerte;

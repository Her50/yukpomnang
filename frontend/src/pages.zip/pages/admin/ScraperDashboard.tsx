﻿import React, { useState } from "react";
import axios from "axios";

const ScraperDashboard: React.FC = () => {
  const [urls, setUrls] = useState<string>("https://example.com,https://exemple.cm");
  const [result, setResult] = useState<any[]>([]);

  const launchScraper = async () => {
    try {
      const list = urls.split(",").map((u) => u.trim());
      const res = await axios.get("/scraper/launch", { params: { urls: list } });
      setResult(res.data.results);
    } catch (err) {
      console.error("Erreur lors du scraping :", err);
      alert("❌ Une erreur est survenue lors du scraping.");
    }
  };

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">🕷️ Scraper Yukpomnang</h2>

      <textarea
        className="w-full border p-2 mb-4"
        rows={3}
        value={urls}
        onChange={(e) => setUrls(e.target.value)}
      />

      <button
        onClick={launchScraper}
        className="bg-blue-600 text-white px-4 py-2 rounded"
      >
        Lancer
      </button>

      <ul className="mt-4 space-y-2">
        {result.map((r, i) => (
          <li key={i} className="border-b py-2">
            {r.name} – {r.url} – {r.location}
          </li>
        ))}
      </ul>

      {result.length === 0 && (
        <p className="text-gray-500 mt-4">Aucun résultat pour l’instant.</p>
      )}
    </div>
  );
};

export default ScraperDashboard;

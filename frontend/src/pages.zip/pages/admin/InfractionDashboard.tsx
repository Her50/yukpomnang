﻿// @ts-check
import React, { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const InfractionDashboard: React.FC = () => {
  const [logs, setLogs] = useState<any[]>([]);
  const [filterIp, setFilterIp] = useState("");
  const [minScore, setMinScore] = useState(0);
  const [days, setDays] = useState(90);

  useEffect(() => {
    fetch("/api/admin/infractions")
      .then((res) => res.json())
      .then(setLogs)
      .catch(console.error);
  }, []);

  const filtered = logs.filter((log) => {
    return (
      log.ip.includes(filterIp) &&
      log.logs.some((l: any) => l.score >= minScore)
    );
  });

  const handlePurge = async () => {
    const res = await fetch("/api/admin/purge-infractions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ days })
    });
    const data = await res.json();
    alert("✅ Purge terminée : " + data.purged + " éléments archivés.");
  };

  const exportCSV = () => {
    const csv = filtered
      .map((log) =>
        log.logs
          .map(
            (l: any) => `${log.ip},${l.path},${l.score},${l.timestamp}`
          )
          .join("\n")
      )
      .join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "infractions.csv";
    a.click();
  };

  return (
    <div className="p-4 text-white dark:bg-black min-h-screen">
      <h1 className="text-2xl font-bold mb-4">🛡️ Infractions détectées</h1>

      <div className="flex flex-wrap gap-4 mb-4 items-center">
        <Button variant="destructive" onClick={handlePurge}>
          🧹 Purger les anciennes
        </Button>
        <input
          type="number"
          value={days}
          onChange={(e) => setDays(Number(e.target.value))}
          className="border px-2 w-20 text-black"
          placeholder="Jours"
        />
        <Button
          variant="outline"
          onClick={() =>
            window.open("/api/admin/export-infractions", "_blank")
          }
        >
          📦 Télécharger ZIP
        </Button>
        <input
          className="px-2 py-1 border rounded text-black"
          placeholder="Filtrer par IP"
          value={filterIp}
          onChange={(e) => setFilterIp(e.target.value)}
        />
        <input
          type="number"
          className="px-2 py-1 border rounded text-black"
          placeholder="Score min"
          value={minScore}
          onChange={(e) => setMinScore(parseInt(e.target.value) || 0)}
        />
        <Button onClick={exportCSV}>📝 Exporter CSV</Button>
      </div>

      {filtered.map((entry, i) => (
        <Card key={i} className="mb-4 bg-gray-900">
          <CardContent>
            <p className="font-bold text-lg">
              IP: {entry.ip}{" "}
              {entry.logs.length >= 3 && (
                <span className="text-red-400">🚨 Récidiviste</span>
              )}
            </p>
            <ul className="text-sm mt-2 ml-4 list-disc">
              {entry.logs.map((l: any, j: number) => (
                <li key={j}>
                  🔒 {l.path} — score: {l.score} — {l.timestamp}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      ))}

      {filtered.length === 0 && (
        <p className="text-center text-gray-400">Aucune infraction trouvée.</p>
      )}
    </div>
  );
};

export default InfractionDashboard;

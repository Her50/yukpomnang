﻿import React, { useState } from "react";
import axios from "axios";

type CertificationResult = {
  status: string;
  badge_url: string;
};

const CertificationPanel: React.FC = () => {
  const [serviceId, setServiceId] = useState("");
  const [level, setLevel] = useState("Bronze");
  const [result, setResult] = useState<CertificationResult | null>(null);

  const handleCertification = async () => {
    try {
      const res = await axios.post(`/api/certify/${serviceId}`, { level });
      setResult(res.data);
    } catch (err) {
      console.error("Erreur certification :", err);
    }
  };

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">🎖️ Certification Yukpomnang Pro</h2>

      <input
        className="border p-2 mb-2 w-full"
        placeholder="ID du service"
        value={serviceId}
        onChange={(e) => setServiceId(e.target.value)}
      />

      <select
        className="border p-2 mb-3 w-full"
        value={level}
        onChange={(e) => setLevel(e.target.value)}
      >
        <option value="Bronze">Bronze</option>
        <option value="Silver">Argent</option>
        <option value="Gold">Or</option>
      </select>

      <button
        className="bg-green-700 text-white p-2 rounded"
        onClick={handleCertification}
      >
        Certifier
      </button>

      {result && (
        <div className="mt-4">
          <p className="text-lg font-semibold">{result.status}</p>
          <img src={result.badge_url} alt="Badge" className="w-24 mt-2" />
        </div>
      )}
    </div>
  );
};

export default CertificationPanel;

﻿// @ts-check
import React from 'react';

function IADashboard() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">🧠 Tableau de bord IA</h1>

      {/* Ajoute ici les sections IA : graphiques, statistiques, suggestions, etc. */}
      <p className="text-gray-600">Bienvenue sur le tableau de bord de l’intelligence artificielle Yukpomnang.</p>
    </div>
  );
}

export default IADashboard;

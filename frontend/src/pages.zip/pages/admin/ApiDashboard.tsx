import React from "react";

const ApiDashboard: React.FC = () => {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">🧩 API Dashboard</h1>
      <p className="text-gray-600">
        Ce tableau de bord affiche les statistiques d’utilisation des API, les performances, et les appels récents.
      </p>
      {/* Tu peux intégrer ici des graphiques, des logs ou un tableau dynamique */}
    </div>
  );
};

export default ApiDashboard;

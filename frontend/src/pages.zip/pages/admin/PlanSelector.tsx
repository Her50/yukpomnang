﻿import React, { useEffect, useState } from "react";
import axios from "axios";

type AccessRegistry = {
  [plan: string]: {
    [permission: string]: boolean;
  };
};

const PlanSelector: React.FC = () => {
  const [data, setData] = useState<AccessRegistry>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const fetchAccess = async () => {
      try {
        const res = await axios.get("/api/admin/access");
        setData(res.data);
      } catch (err) {
        console.error("Erreur de chargement", err);
      } finally {
        setLoading(false);
      }
    };
    fetchAccess();
  }, []);

  const togglePermission = (plan: string, permission: string) => {
    setData((prev) => ({
      ...prev,
      [plan]: {
        ...prev[plan],
        [permission]: !prev[plan][permission],
      },
    }));
  };

  const save = async () => {
    setSaving(true);
    try {
      await axios.post("/api/admin/update-access", data);
      alert("✅ Sauvegarde réussie");
    } catch (err) {
      alert("❌ Erreur de sauvegarde");
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <p>⏳ Chargement des données...</p>;

  return (
    <div className="p-6">
      <h1 className="text-xl font-bold mb-4">⚙️ Gestion des Permissions par Plan</h1>
      <table className="w-full border border-gray-300">
        <thead>
          <tr className="bg-gray-100">
            <th className="p-2 border">Permission</th>
            {Object.keys(data).map((plan) => (
              <th key={plan} className="p-2 border">{plan.toUpperCase()}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {/* On suppose que tous les plans ont les mêmes permissions */}
          {Object.keys(data[Object.keys(data)[0]]).map((perm) => (
            <tr key={perm}>
              <td className="p-2 border">{perm}</td>
              {Object.keys(data).map((plan) => (
                <td className="p-2 border text-center" key={`${plan}-${perm}`}>
                  <input
                    type="checkbox"
                    checked={data[plan][perm]}
                    onChange={() => togglePermission(plan, perm)}
                  />
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>

      <button
        className="mt-4 px-4 py-2 bg-blue-600 text-white rounded"
        onClick={save}
        disabled={saving}
      >
        {saving ? "Enregistrement..." : "💾 Enregistrer"}
      </button>
    </div>
  );
};

export default PlanSelector;

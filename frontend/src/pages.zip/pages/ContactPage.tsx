﻿import React, { useState } from 'react';
import RequirePlan from '@/components/security/RequirePlan';
import RequireRole from '@/components/auth/RequireRole';

function ContactPage() {
  const [form, setForm] = useState({ nom: '', email: '', message: '' });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      setSuccess(res.ok);
    } catch (err) {
      console.error('Erreur lors de l’envoi :', err);
      setSuccess(false);
    }
    setLoading(false);
  };

  return (
    <RequirePlan plan="pro">
      <RequireRole role="user">
        <div className="pt-24 max-w-xl mx-auto">
          <h2 className="text-3xl font-bold mb-6 text-center">Nous contacter</h2>

          <form className="space-y-4" onSubmit={handleSubmit}>
            <input
              type="text"
              name="nom"
              placeholder="Nom"
              value={form.nom}
              onChange={handleChange}
              className="w-full px-4 py-2 border rounded"
              required
            />
            <input
              type="email"
              name="email"
              placeholder="Email"
              value={form.email}
              onChange={handleChange}
              className="w-full px-4 py-2 border rounded"
              required
            />
            <textarea
              name="message"
              placeholder="Message"
              value={form.message}
              onChange={handleChange}
              className="w-full px-4 py-2 border rounded h-32"
              required
            />
            <button
              type="submit"
              className="w-full bg-green-600 text-white py-2 rounded hover:bg-green-700"
              disabled={loading}
            >
              {loading ? 'Envoi en cours...' : 'Envoyer'}
            </button>
            {success && (
              <div className="text-green-600 font-semibold text-center">
                ✅ Message envoyé avec succès.
              </div>
            )}
          </form>
        </div>
      </RequireRole>
    </RequirePlan>
  );
}

export default ContactPage;

// @ts-check
import React, { useEffect } from "react";

// Composants d'administration
import FixFrontendButton from "@/components/admin/FixFrontendButton";
import SchedulerStatusCard from "@/components/SchedulerStatusCard";
import ScheduleManager from "@/components/admin/ScheduleManager";
import QuotaDashboard from "@/components/admin/QuotaDashboard";
import NotificationLog from "@/components/admin/NotificationLog";
import ApiKeyManager from "@/components/admin/ApiKeyManager";

// Sécurité
import RequirePlan from "@/components/security/RequirePlan";
import RequireRole from "@/components/auth/RequireRole";

interface BlockStatus {
  status: string;
}

const AdminPanel: React.FC = () => {
  useEffect(() => {
    fetch("/api/admin/block-status")
      .then((res) => res.json())
      .then((data: BlockStatus[]) => {
        const pending = data.find((b) => b.status.includes("⏳"));
        if (pending) {
          window.location.href = "/admin/blocks-status";
        }
      });
  }, []);

  const handleVerifyBooks = async () => {
    try {
      const res = await fetch("/admin/verify-books");
      const data = await res.json();
      alert("📚 Vérification terminée. Résultat dans la console.");
      console.log(data);
    } catch (err) {
      console.error("❌ Erreur de vérification :", err);
    }
  };

  return (
    <RequirePlan plan="pro">
      <RequireRole role="user">
        <div className="pt-24 p-8 min-h-screen bg-white font-inter">
          <h1 className="text-3xl font-bold mb-6">🛠️ Console d’administration Yukpomnang</h1>

          <div className="flex flex-col gap-4 mb-6">
            <button
              onClick={handleVerifyBooks}
              className="bg-green-600 text-white px-6 py-3 rounded hover:bg-green-700"
            >
              📚 Vérifier disponibilité des livres
            </button>

            <a
              href="/admin/purge-log"
              className="bg-orange-500 text-white px-4 py-2 rounded hover:bg-orange-600 inline-block"
            >
              🕓 Historique des purges
            </a>

            <a
              href="/admin/blocks-status"
              className="block px-4 py-2 rounded bg-gray-100 hover:bg-gray-200 text-sm"
            >
              🧠 Blocs IA
            </a>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <ScheduleManager />
            <SchedulerStatusCard />
            <QuotaDashboard />
            <FixFrontendButton />
            <ApiKeyManager />
          </div>

          <div className="mt-10">
            <h3 className="text-xl font-semibold mb-2">📢 Notifications</h3>
            <NotificationLog />
          </div>
        </div>
      </RequireRole>
    </RequirePlan>
  );
};

export default AdminPanel;

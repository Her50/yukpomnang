import React from "react";

const CaptchaPage: React.FC = () => {
  return (
    <div className="p-4">
      <h2>CaptchaPage</h2>
    </div>
  );
};

export default CaptchaPage;

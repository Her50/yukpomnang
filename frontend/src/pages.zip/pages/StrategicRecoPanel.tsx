﻿// @ts-check
import React, { useState } from 'react';
import RequirePlan from '@/components/security/RequirePlan'; // ✅ Corrigé : import par défaut

interface Reco {
  type: string;
  conseil: string;
}

const recoData: Reco[] = [
  { type: 'marché', conseil: 'Investir davantage dans les villes secondaires.' },
  { type: 'contenu', conseil: 'Publier aux heures de forte audience détectées (12h-13h, 19h-21h).' },
  { type: 'audience', conseil: 'Cibler davantage les jeunes professionnels mobiles.' },
];

const StrategicRecoPanel: React.FC = () => {
  const [plan, setPlan] = useState<string>('free');

  const handleExport = (type: string) => {
    if (type === 'pdf') alert('📄 Génération PDF simulée...');
    if (type === 'whatsapp') alert('📲 Envoi WhatsApp simulé...');
  };

  return (
    <div className="pt-24 pb-32 px-6 min-h-screen bg-white" style={{ fontFamily: "'Inter', sans-serif" }}>
      <h1 className="text-3xl font-bold text-center mb-10">🧠 Recommandations Stratégiques Yukpomnang</h1>

      <div className="max-w-4xl mx-auto space-y-6">
        {recoData.map((r, i) => (
          <div key={i} className="bg-gray-50 border-l-4 border-orange-500 p-4 rounded shadow-sm">
            <p className="text-sm text-gray-500 mb-1 uppercase font-semibold">{r.type}</p>
            <p className="text-lg text-gray-800 font-medium">{r.conseil}</p>
          </div>
        ))}
      </div>

      <div className="mt-10 text-center">
        <RequirePlan plan="enterprise">
          {plan === 'free' ? (
            <div className="text-red-600 font-semibold">🔒 Export réservé aux utilisateurs Premium</div>
          ) : (
            <div>
              <button
                onClick={() => handleExport('pdf')}
                className="px-6 py-2 bg-orange-600 text-white rounded-md mr-4"
              >
                📄 Exporter en PDF
              </button>
              <button
                onClick={() => handleExport('whatsapp')}
                className="px-6 py-2 bg-green-600 text-white rounded-md"
              >
                📲 Envoyer par WhatsApp
              </button>
            </div>
          )}
        </RequirePlan>
      </div>
    </div>
  );
};

export default StrategicRecoPanel;

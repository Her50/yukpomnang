import React from "react";

const CookiePage: React.FC = () => {
  return (
    <div className="p-4">
      <h2>CookiePage</h2>
    </div>
  );
};

export default CookiePage;

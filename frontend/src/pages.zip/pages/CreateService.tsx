﻿import React, { useState } from "react";
import axios from "axios";

export default function CreateService() {
  const [form, setForm] = useState({
    title: "",
    description: "",
    category: "",
    location: "",
  });
  const [link, setLink] = useState("");

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async () => {
    try {
      const res = await axios.post("/services/create", form);
      setLink(res.data.link);
    } catch (err) {
      console.error("Erreur lors de la création du service :", err);
    }
  };

  return (
    <div className="p-6 max-w-xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">Publier un service</h2>
      <input
        name="title"
        onChange={handleChange}
        placeholder="Nom du service"
        className="border p-2 w-full mb-2"
      />
      <input
        name="category"
        onChange={handleChange}
        placeholder="Catégorie"
        className="border p-2 w-full mb-2"
      />
      <input
        name="location"
        onChange={handleChange}
        placeholder="Lieu"
        className="border p-2 w-full mb-2"
      />
      <textarea
        name="description"
        onChange={handleChange}
        placeholder="Description"
        className="border p-2 w-full mb-2"
      />
      <button
        onClick={handleSubmit}
        className="bg-green-600 text-white px-4 py-2 rounded"
      >
        Publier
      </button>

      {link && (
        <p className="mt-4">
          Lien généré :{" "}
          <a href={link} className="text-blue-600 underline" target="_blank" rel="noopener noreferrer">
            {link}
          </a>
        </p>
      )}
    </div>
  );
}

﻿// @ts-check
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import RequirePlan from '@/components/security/RequirePlan';

const PaiementProPage: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const navigate = useNavigate();

  const handlePaiement = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSuccess(true);
      setTimeout(() => {
        navigate('/dashboard');
      }, 2500);
    }, 2000);
  };

  return (
    <RequirePlan plan="pro">
      <div className="pt-24 px-6 min-h-screen bg-white font-inter">
        <div className="max-w-md mx-auto bg-gray-100 p-6 rounded-xl shadow-md text-center">
          <h1 className="text-2xl font-bold mb-4">💳 Paiement Plan Pro</h1>

          {loading ? (
            <p>Chargement en cours...</p>
          ) : success ? (
            <p className="text-green-600 font-semibold">✅ Paiement effectué avec succès !</p>
          ) : (
            <button
              onClick={handlePaiement}
              className="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700 transition"
            >
              Payer maintenant
            </button>
          )}
        </div>
      </div>
    </RequirePlan>
  );
};

export default PaiementProPage;

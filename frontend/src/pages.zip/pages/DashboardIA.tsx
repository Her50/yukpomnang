// @ts-check
import React, { useState } from "react";
import { Yukpomnang_PRODUCTS, getProductsByPlan } from "@/lib/IAProductRegistry";
import Tabs from "@/components/ui/tabs/Tabs";
import TabsList from "@/components/ui/tabs/TabsList";
import TabsTrigger from "@/components/ui/tabs/TabsTrigger";
import TabsContent from "@/components/ui/tabs/TabsContent";
import { Card, CardContent } from "@/components/ui/card";
import RequirePlan from "@/components/security/RequirePlan";

const plans = ["free", "pro", "enterprise"] as const;
type YukpomnangPlan = typeof plans[number];

const DashboardIA: React.FC = () => {
  const [plan, setPlan] = useState<YukpomnangPlan>("free");

  return (
    <div className="pt-24 px-6 max-w-5xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">🤖 Tableau de bord IA Yukpomnang</h1>

      <Tabs defaultValue={plan} onValueChange={(val) => setPlan(val as YukpomnangPlan)}>
        <TabsList>
          <TabsTrigger value="free">🟢 Gratuit</TabsTrigger>
          <TabsTrigger value="pro">🟡 Pro</TabsTrigger>
          <TabsTrigger value="enterprise">🔴 Entreprise</TabsTrigger>
        </TabsList>

        {plans.map((level) => (
          <TabsContent key={level} value={level}>
            <RequirePlan plan={level}>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mt-6">
                {getProductsByPlan(level).map((product) => (
                  <Card key={product.id} className="border shadow">
                    <CardContent className="p-4">
                      <h3 className="text-lg font-semibold mb-2">{product.name}</h3>
                      <p className="text-sm text-gray-600">{product.description}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </RequirePlan>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
};

export default DashboardIA;

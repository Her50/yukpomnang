﻿import { toast } from "react-toastify";
import useProximityDetector from "@/hooks/useProximityDetector";
import React, { useState } from "react";
import axios from "axios";

const ServiceLocator: React.FC = () => {
  const [location, setLocation] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const handleLocate = async () => {
    try {
      setLoading(true);
      const res = await axios.post("/api/service-location", { service_id: "12345" });
      setLocation(res.data);

      if (res.data.latitude && res.data.longitude) {
        useProximityDetector(res.data.latitude, res.data.longitude, () => {
          toast.success("🛰️ Vous êtes proche de ce service ! Redirection...");
          setTimeout(() => {
            window.open(
              `https://www.google.com/maps/dir/?api=1&destination=${res.data.latitude},${res.data.longitude}`,
              "_blank"
            );
          }, 2500);
        });

        // Si pas de déclenchement automatique, ouvrir quand même
        window.open(
          `https://www.google.com/maps/dir/?api=1&destination=${res.data.latitude},${res.data.longitude}`,
          "_blank"
        );
      }
    } catch (error) {
      toast.error("Erreur de localisation du service");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">📍 Localiser le service</h2>
      <button
        onClick={handleLocate}
        className="bg-blue-600 text-white px-4 py-2 rounded"
        disabled={loading}
      >
        {loading ? "Chargement..." : "🚗 Activer le GPS"}
      </button>
      {location && (
        <p className="mt-4">📌 Adresse : {location.address}</p>
      )}
    </div>
  );
};

export default ServiceLocator;

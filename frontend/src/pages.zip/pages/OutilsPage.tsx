﻿// @ts-check
import React from 'react';
import styled, { keyframes } from 'styled-components';
import RequirePlan from '@/components/security/RequirePlan';
import RequireRole from '@/components/auth/RequireRole';

const pulseAnimation = keyframes`
  0% { transform: scale(1); opacity: 1; }
  50% { transform: scale(1.05); opacity: 0.75; }
  100% { transform: scale(1); opacity: 1; }
`;

const PulseBox = styled.div`
  animation: ${pulseAnimation} 2s infinite;
  padding: 20px;
  text-align: center;
  background-color: #f3f4f6;
  border-radius: 12px;
  margin: 40px auto;
  width: 300px;
  font-size: 18px;
  font-weight: bold;
`;

const OutilsPage: React.FC = () => {
  return (
    <RequirePlan plan="pro">
      <RequireRole role="user">
        <div className="pt-24 min-h-screen bg-white" style={{ fontFamily: "'Inter', sans-serif" }}>
          <h1 className="text-3xl text-center mb-10 font-bold">🛠️ Outils Yukpomnang</h1>
          <PulseBox>⚙️ Module Yukpomnang en cours d’activation...</PulseBox>
        </div>
      </RequireRole>
    </RequirePlan>
  );
};

export default OutilsPage;

import React from "react";

const TranslationTestPage: React.FC = () => {
  return (
    <div className="p-4">
      <h2>TranslationTestPage</h2>
    </div>
  );
};

export default TranslationTestPage;

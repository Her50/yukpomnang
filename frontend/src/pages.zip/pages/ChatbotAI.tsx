﻿import React, { useState } from "react";

export default function ChatbotAI() {
  const [prompt, setPrompt] = useState("");
  const [reply, setReply] = useState("");

  const handleAsk = async () => {
    try {
      const res = await fetch("/api/ask", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
      });
      const data = await res.json();
      setReply(data.reply || "Aucune réponse.");
    } catch (error) {
      setReply("❌ Une erreur est survenue.");
    }
  };

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">🤖 Chatbot Yukpomnang</h2>
      <input
        className="border p-2 w-full mb-2"
        placeholder="Posez votre question"
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
      />
      <button
        className="bg-blue-600 text-white px-4 py-2 rounded"
        onClick={handleAsk}
      >
        Demander
      </button>
      {reply && (
        <div className="mt-4 bg-gray-100 p-3 rounded">
          {reply}
        </div>
      )}
    </div>
  );
}

﻿// @ts-check
import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import RequirePlan from "@/components/security/RequirePlan";
import RequireRole from "@/components/auth/RequireRole";

const LoginPage: React.FC = () => {
  const location = useLocation();
  const [showLogoutMessage, setShowLogoutMessage] = useState(false);

  useEffect(() => {
    if (location.state?.loggedOut) {
      setShowLogoutMessage(true);
      window.history.replaceState({}, document.title);
    }
  }, [location.state]);

  return (
    <RequirePlan plan="pro">
      <RequireRole role="user">
        <div className="p-8 max-w-md mx-auto pt-24">
          {showLogoutMessage && (
            <div className="mb-4 bg-green-100 text-green-800 px-4 py-2 rounded shadow">
              ✅ Vous êtes bien déconnecté.
            </div>
          )}

          <h1 className="text-2xl font-bold mb-6 text-center">🔐 Connexion</h1>

          <form className="flex flex-col gap-4">
            <input
              type="email"
              placeholder="Email"
              className="border p-2 rounded"
            />
            <input
              type="password"
              placeholder="Mot de passe"
              className="border p-2 rounded"
            />
            <button className="bg-blue-600 text-white py-2 rounded">
              Se connecter
            </button>
          </form>
        </div>
      </RequireRole>
    </RequirePlan>
  );
};

export default LoginPage;

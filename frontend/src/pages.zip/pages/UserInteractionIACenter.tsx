﻿// @ts-check
import React from 'react';
import RequirePlan from '@/components/security/RequirePlan'; // ✅ import par défaut correct

const logs = [
  { type: 'clic', action: "Clic sur bouton 'Créer un service'", time: '2025-05-01 14:23' },
  {
    type: 'vue',
    action: 'Visite de la page Yukpomnang Premium',
    time: '2025-05-01 14:25',
    plan: 'enterprise',
  },
];

const UserInteractionIACenter: React.FC = () => {
  return (
    <div className="pt-24 pb-32 px-6 sm:px-10 max-w-4xl mx-auto font-inter">
      <h1 className="text-3xl font-bold mb-8">🧠 Interactions IA</h1>

      <ul className="space-y-6">
        {logs.map((log, index) => (
          <li key={index} className="border-b pb-4">
            <p className="font-semibold">{log.action}</p>
            <p className="text-sm text-gray-500">{log.time}</p>

            {log.plan === 'enterprise' ? (
              <RequirePlan plan="enterprise">
                <p className="mt-2 text-orange-600">🔒 Accès réservé aux comptes Premium</p>
              </RequirePlan>
            ) : null}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default UserInteractionIACenter;

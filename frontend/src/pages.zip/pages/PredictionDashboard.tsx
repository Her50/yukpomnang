﻿// @ts-check
import React, { useState } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";
import RequirePlan from "@/components/security/RequirePlan";

const chartData = [
  { month: "Jan", demandes: 20 },
  { month: "Fév", demandes: 35 },
  { month: "Mar", demandes: 50 },
  { month: "Avr", demandes: 65 },
  { month: "Mai", demandes: 80 },
  { month: "Juin", demandes: 95 },
  { month: "Juil", demandes: 120 },
];

const PredictionDashboard: React.FC = () => {
  const [plan, setPlan] = useState("free");

  return (
    <div className="pt-24 pb-32 px-6 min-h-screen bg-white" style={{ fontFamily: "'Inter', sans-serif" }}>
      <RequirePlan plan="pro">
        <h1 className="text-3xl font-bold text-center mb-10">📈 Analyse prédictive Yukpomnang</h1>

        <div className="max-w-4xl mx-auto">
          <div className="bg-gray-50 p-6 rounded-lg shadow-md mb-6">
            <h2 className="text-2xl font-semibold text-gray-800 mb-4">📊 Tendances des demandes</h2>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="demandes" stroke="#FF5722" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </RequirePlan>

      {plan === "free" && (
        <div className="text-center text-red-600 font-semibold mt-10">
          🔒 Export réservé aux utilisateurs Premium
        </div>
      )}
    </div>
  );
};

export default PredictionDashboard;

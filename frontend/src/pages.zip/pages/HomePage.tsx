﻿import React from "react";
import { detectBrowserLanguage } from "@/utils/detectLanguage";
import { useWelcomeAudio } from "@/hooks/useWelcomeAudio";

const HomePage: React.FC = () => {
  const language = detectBrowserLanguage();
  useWelcomeAudio(language);

  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center px-6">
      <h1 className="text-4xl md:text-5xl font-bold mb-6 text-center text-[#C8102E]">
        Bienvenue sur Yukpomnang
      </h1>
      <p className="text-gray-700 text-lg text-center mb-8 max-w-xl">
        Yukpomnang connecte intelligemment les utilisateurs aux meilleurs services autour d’eux. Cliquez ci-dessous pour démarrer votre expérience.
      </p>
      <button className="bg-[#C8102E] text-white px-6 py-3 rounded-2xl shadow-md text-lg hover:scale-105 transition">
        Démarrer l’expérience
      </button>
    </div>
  );
};

export default HomePage;

﻿// @ts-check
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUser } from '@/hooks/useUser';
import RequireRole from '@/components/auth/RequireRole';
import RequireAnyRole from '@/components/auth/RequireAnyRole';
import RequireNotRole from '@/components/auth/RequireNotRole';
import type { Role } from '@/types/roles'; // Assure-toi que ce fichier existe

function DebugRolesPage() {
  const { user } = useUser();
  const navigate = useNavigate();

  useEffect(() => {
    if (!user || user.role !== 'admin') {
      navigate('/login');
    }
  }, [user, navigate]);

  if (!user || user.role !== 'admin') {
    return null;
  }

  return (
    <div className="max-w-2xl mx-auto p-8">
      <h1 className="text-3xl font-bold mb-6">🛡️ Debug des rôles Yukpomnang</h1>

      <div className="mb-4 text-gray-800">
        <p>
          Rôle actuel : <strong>{user.role}</strong>
        </p>
      </div>

      <div className="space-y-4">
        <RequireRole role="admin">
          <div className="p-4 bg-green-100 border rounded">
            ✅ Visible pour : <strong>admin</strong>
          </div>
        </RequireRole>

        <RequireAnyRole roles={["admin", "user"]}>
          <div className="p-4 bg-blue-100 border rounded">
            ✅ Visible pour : <strong>admin</strong> ou <strong>user</strong>
          </div>
        </RequireAnyRole>

        <RequireNotRole role="client">
          <div className="p-4 bg-yellow-100 border rounded">
            ✅ Visible pour tous sauf : <strong>client</strong>
          </div>
        </RequireNotRole>

        <RequireRole role="visitor">
          <div className="p-4 bg-red-100 border rounded">
            ❌ Visible uniquement pour : <strong>visitor</strong>
          </div>
        </RequireRole>
      </div>
    </div>
  );
}

export default DebugRolesPage;

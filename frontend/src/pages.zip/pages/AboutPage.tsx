﻿import React from 'react';
import RequirePlan from '@/components/security/RequirePlan';
import RequireRole from '@/components/auth/RequireRole';

const AboutPage: React.FC = () => {
  return (
    <RequirePlan plan="pro">
      <RequireRole role="user">
        <div className="pt-24 max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">À propos de Yukpomnang</h2>
          <p className="text-gray-700">
            Yukpomnang est une plateforme intelligente qui écoute, comprend et agit selon vos besoins.
            Propulsée par l'IA, elle vous connecte aux meilleures solutions disponibles.
          </p>
        </div>
      </RequireRole>
    </RequirePlan>
  );
};

export default AboutPage;

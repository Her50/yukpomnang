import React from "react";

const DashboardSelector: React.FC = () => {
  return (
    <div className="p-4">
      <h2>DashboardSelector</h2>
    </div>
  );
};

export default DashboardSelector;

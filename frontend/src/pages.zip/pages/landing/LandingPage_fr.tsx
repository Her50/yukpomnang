import React from "react";

const LandingPage_fr: React.FC = () => {
  return (
    <div className="p-4">
      <h2>LandingPage_fr</h2>
    </div>
  );
};

export default LandingPage_fr;

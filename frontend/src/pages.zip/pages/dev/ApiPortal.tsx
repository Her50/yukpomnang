import React from "react";

const ApiPortal: React.FC = () => {
  return (
    <div className="p-4">
      <h2>ApiPortal</h2>
    </div>
  );
};

export default ApiPortal;

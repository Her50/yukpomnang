﻿// @ts-check
import React from "react";
import styled, { keyframes } from "styled-components";
import RequirePlan from "@/components/security/RequirePlan";

// Animation MatchPage
const pulse = keyframes`
  0% { transform: scale(1); opacity: 1; }
  50% { transform: scale(1.05); opacity: 0.75; }
  100% { transform: scale(1); opacity: 1; }
`;

// Styled component
const PulseBox = styled.div`
  animation: ${pulse} 2s infinite;
`;

const MatchPage: React.FC = () => {
  const data = {
    plan: "free", // à connecter à ton vrai contexte utilisateur
    ia_response: "Voici les correspondances Yukpomnang générées selon votre besoin.",
  };

  return (
    <div className="pt-24 pb-32 px-8" style={{ fontFamily: "'Inter', sans-serif" }}>
      <h1 className="text-3xl font-bold mb-6">🎯 Mise en relation intelligente</h1>

      <PulseBox className="bg-gray-100 p-6 rounded-lg shadow text-center">
        <p className="text-lg font-medium text-gray-700">{data.ia_response}</p>
      </PulseBox>

      {data.plan === "free" && (
        <div className="mt-6 text-center text-red-600 font-semibold">
          <RequirePlan plan="pro">
            Certaines suggestions Premium sont désactivées. Mettez à jour votre plan pour débloquer tout le potentiel de l’IA.
          </RequirePlan>
        </div>
      )}
    </div>
  );
};

export default MatchPage;

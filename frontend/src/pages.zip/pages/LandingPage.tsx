﻿// @ts-check
import React, { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import axios from "axios";

const LandingPage: React.FC = () => {
  const [params] = useSearchParams();
  const [data, setData] = useState<{
    title: string;
    description: string;
    keywords: string[];
  } | null>(null);

  useEffect(() => {
    const country = params.get("LandingPage") || "Cameroun";
    const sector = params.get("sector") || "immobilier";
    axios
      .get("/landing", { params: { country, sector } })
      .then((res) => setData(res.data))
      .catch((err) => console.error("Erreur chargement landing :", err));
  }, [params]);

  if (!data) return <div>Chargement...</div>;

  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold">{data.title}</h1>
      <p className="mt-2">{data.description}</p>
      <p className="text-sm text-gray-500 mt-1">
        Mots-clés : {Array.isArray(data.keywords) ? data.keywords.join(", ") : "Aucun"}
      </p>
    </div>
  );
};

export default LandingPage;

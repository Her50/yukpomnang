import React from "react";
import AccessAuditTable from "@/components/security/AccessAuditTable";

const AdminAccessAudit = () => {
  return (
    <div>
      <AccessAuditTable />
    </div>
  );
};

export default AdminAccessAudit;

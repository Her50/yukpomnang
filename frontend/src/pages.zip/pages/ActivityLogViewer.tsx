﻿// @ts-check
import React, { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";

interface LogEntry {
  timestamp: string;
  user: string;
  action: string;
  module: string;
  status: string;
}

const ActivityLogViewer: React.FC = () => {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [filter, setFilter] = useState("");

  useEffect(() => {
    fetch("/activity_log.json")
      .then((res) => res.text())
      .then((text) => {
        const lines = text.trim().split("\n");
        const parsed = lines.map((line) => JSON.parse(line));
        setLogs(parsed);
      });
  }, []);

  const filtered = logs.filter((l) =>
    filter ? l.action.includes(filter) || l.module.includes(filter) : true
  );

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">🧾 Historique des actions admin</h2>
      <input
        placeholder="Filtrer par action/module"
        className="p-2 border border-gray-300 mb-4 w-full"
        onChange={(e) => setFilter(e.target.value)}
      />
      <table className="w-full text-left border border-collapse">
        <thead className="bg-gray-100">
          <tr>
            <th className="border px-2 py-1">Date</th>
            <th className="border px-2 py-1">Utilisateur</th>
            <th className="border px-2 py-1">Action</th>
            <th className="border px-2 py-1">Module</th>
            <th className="border px-2 py-1">Status</th>
          </tr>
        </thead>
        <tbody>
          {filtered.map((log, i) => (
            <tr key={i} className="border-t">
              <td className="border px-2 py-1">{log.timestamp}</td>
              <td className="border px-2 py-1">{log.user}</td>
              <td className="border px-2 py-1">{log.action}</td>
              <td className="border px-2 py-1">{log.module}</td>
              <td className="border px-2 py-1">{log.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ActivityLogViewer;

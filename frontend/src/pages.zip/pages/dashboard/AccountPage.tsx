﻿import React from 'react';
import { RecentViewed } from '@/components/history/RecentViewed';
// import { MessageInbox } from '@/components/...'; // à activer si disponible

function AccountPage() {
  const user = { id: 1, plan: 'Pro', factureUrl: '/pdfs/facture_1.pdf' };

  const envoyerFacture = async () => {
    try {
      await fetch(`/api/facture/${user.id}/send`);
      alert('📤 Facture envoyée via WhatsApp ou Email !');
    } catch (error) {
      console.error("Erreur d'envoi :", error);
      alert("❌ Échec de l'envoi de la facture.");
    }
  };

  return (
    <div className="p-8 space-y-6">
      <h1 className="text-xl font-bold">Mon Compte</h1>

      <p>
        Plan actuel :{" "}
        <span className="font-semibold">{user.plan}</span>
      </p>

      <a
        href={user.factureUrl}
        target="_blank"
        className="text-blue-500 underline"
        rel="noreferrer"
      >
        📄 Télécharger ma facture
      </a>

      <button
        onClick={envoyerFacture}
        className="bg-green-600 px-4 py-2 text-white rounded"
      >
        📤 Envoyer facture
      </button>

      <RecentViewed userId={user.id} />

      {/* Activer ci-dessous si MessageInbox est bien importé */}
      {/* <MessageInbox userId={user.id} /> */}
    </div>
  );
}

export default AccountPage;

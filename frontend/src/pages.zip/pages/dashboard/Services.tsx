﻿import React from 'react';
import BusinessServiceCard from "@/components/cards/ServiceCard";

const Services = [
  { nom: 'Yukpomnang Immobilier', description: 'Publication de biens professionnels', prix: 15000 },
  { nom: 'Yukpomnang Transport', description: 'Réservation billets + hôtels partenaires', prix: 20000 },
];

function ServicesPage() {
  return (
    <div className="p-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
      {Services.map((s, i) => (
        <BusinessServiceCard key={i} {...s} />
      ))}
    </div>
  );
}

export default ServicesPage;

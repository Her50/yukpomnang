import React from "react";

const History: React.FC = () => {
  return (
    <div className="p-4">
      <h2>History</h2>
    </div>
  );
};

export default History;

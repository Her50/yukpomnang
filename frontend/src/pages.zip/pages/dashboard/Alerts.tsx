import React from "react";

const Alerts: React.FC = () => {
  return (
    <div className="p-4">
      <h2>Alerts</h2>
    </div>
  );
};

export default Alerts;

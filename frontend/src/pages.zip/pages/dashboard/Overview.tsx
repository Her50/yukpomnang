import React from "react";

const Overview: React.FC = () => {
  return (
    <div className="p-4">
      <h2>Overview</h2>
    </div>
  );
};

export default Overview;

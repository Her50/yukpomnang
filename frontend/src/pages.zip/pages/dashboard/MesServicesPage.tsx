﻿import React from 'react';
import { MesServicesList } from '@/components/dashboard/MesServicesList';

function MesServicesPage() {
  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">📦 Mes services</h2>
      <MesServicesList />
    </div>
  );
}

export default MesServicesPage;

﻿import React from "react";
import RequirePlan from "@/components/security/RequirePlan"; // ✅ import par défaut

const IAPremium: React.FC = () => {
  return (
    <div className="p-8 pt-24 max-w-6xl mx-auto">
      <RequirePlan plan="enterprise">
        <h1 className="text-3xl font-bold mb-8 text-center">
          🧠 Yukpomnang Premium
        </h1>

        <p className="text-lg text-center text-gray-700">
          Accédez aux fonctionnalités exclusives d'intelligence artificielle :
          génération automatique, prédictions intelligentes, suggestions IA,
          matching vocal et bien plus encore.
        </p>
      </RequirePlan>
    </div>
  );
};

export default IAPremium;

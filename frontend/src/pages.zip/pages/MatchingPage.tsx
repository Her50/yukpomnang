﻿// @ts-check
import React, { useState } from "react";
import RequirePlan from "@/components/security/RequirePlan";

const MatchingPage: React.FC = () => {
  const [plan, setPlan] = useState("free");

  return (
    <div
      className="pt-24 pb-32 px-6 min-h-screen bg-white"
      style={{ fontFamily: "'Inter', sans-serif" }}
    >
      <h1 className="text-3xl font-bold text-center mb-10">
        Mise en relation intelligente
      </h1>

      <div className="max-w-4xl mx-auto space-y-6">
        <p className="text-lg font-medium">
          Suggestions pour votre profil :
        </p>

        <RequirePlan plan="enterprise">
          <div className="mt-10 text-center text-red-600 font-semibold">
            Certaines suggestions avancées sont réservées aux comptes Premium.
          </div>
        </RequirePlan>
      </div>
    </div>
  );
};

export default MatchingPage;

﻿// @ts-check
import React, { useState } from 'react';

export default function CommunicationPanel() {
  const [status, setStatus] = useState('');

  const sendAction = async (type: string) => {
    setStatus('⏳ Envoi en cours...');
    try {
      const res = await fetch(`/send/${type}`);
      const json = await res.json();
      setStatus(json.status || json.error || '✅ Action terminée');
    } catch (err) {
      setStatus('❌ Erreur réseau');
    }
  };

  const generatePdf = async () => {
    setStatus('⏳ Génération PDF...');
    try {
      const res = await fetch('/admin/generate-pdf');
      const json = await res.json();
      setStatus(json.status || json.error || '✅ PDF généré');
    } catch (err) {
      setStatus('❌ Erreur lors du PDF');
    }
  };

  return (
    <div className="pt-24 pb-32 px-6 bg-white min-h-screen font-sans">
      <h1 className="text-3xl font-bold text-center mb-10">
        📨 Centre Yukpomnang : Export & Partage
      </h1>

      <div className="max-w-2xl mx-auto grid gap-6">
        <button
          onClick={generatePdf}
          className="bg-green-600 text-white py-3 px-6 rounded hover:bg-green-700"
        >
          📄 Générer un PDF Yukpomnang
        </button>

        <button
          onClick={() => sendAction('email')}
          className="bg-blue-600 text-white py-3 px-6 rounded hover:bg-blue-700"
        >
          ✉️ Envoyer par Email
        </button>

        <button
          onClick={() => sendAction('whatsapp')}
          className="bg-lime-600 text-white py-3 px-6 rounded hover:bg-lime-700"
        >
          📲 Partager via WhatsApp
        </button>
      </div>

      {status && (
        <div className="mt-10 text-center font-semibold text-orange-700">
          {status}
        </div>
      )}

      <footer className="text-center text-sm text-gray-500 mt-20 border-t pt-6">
        Yukpomnang Connect — Communication multicanal © 2025
      </footer>
    </div>
  );
}

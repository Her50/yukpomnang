import React from 'react';
import { useParams } from 'react-router-dom';
import VariationAlert from '@/components/variation/VariationAlert';

const SingleServicePage: React.FC = () => {
  const { id } = useParams<{ id?: string }>();

  const parsedId = Number(id);

  if (!id || isNaN(parsedId)) {
    return (
      <div className="p-6 text-red-600 font-medium">
        ⚠️ Identifiant de service invalide ou manquant dans l’URL.
      </div>
    );
  }

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">🧩 Détail du service #{parsedId}</h1>
      <VariationAlert serviceId={parsedId} />
    </div>
  );
};

export default SingleServicePage;

﻿// @ts-check
import React from "react";
import QuotaDashboard from "@/components/admin/QuotaDashboard"; // ✅ chemin corrigé

const AdminQuotaPage: React.FC = () => {
  return (
    <div className="p-4">
      <QuotaDashboard />
    </div>
  );
};

export default AdminQuotaPage;

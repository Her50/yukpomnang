export { default as Tabs } from "./Tabs";
export { default as TabsList } from "./TabsList";
export { default as TabsTrigger } from "./TabsTrigger";
export { default as TabsContent } from "./TabsContent";

import React from "react";

const RolePlanNotice: React.FC = () => {
  return (
    <div className="p-4">
      <h2>RolePlanNotice</h2>
    </div>
  );
};

export default RolePlanNotice;

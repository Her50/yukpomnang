import React from "react";

const UpgradeBanner: React.FC = () => {
  return (
    <div className="p-4">
      <h2>UpgradeBanner</h2>
    </div>
  );
};

export default UpgradeBanner;

﻿// @generated
import React, { useEffect, useState } from 'react';

type Message = {
  id: string;
  sender_id: string;
  receiver_id: string;
  content: string;
  created_at: string;
  read: boolean;
};

function MessageInbox({ userId }: { userId: string }) {
  const [messages, setMessages] = useState<Message[]>([]);

  useEffect(() => {
    fetch(`/api/messages/${userId}`)
      .then((res) => res.json())
      .then(setMessages);
  }, [userId]);

  return (
    <div className="bg-white p-4 rounded-xl shadow">
      <h2 className="text-lg font-bold mb-4">Messages reçus</h2>
      <ul>
        {messages.map((msg) => (
          <li key={msg.id} className="border-b py-2">
            <p className="text-sm">{msg.content}</p>
            <p className="text-xs text-gray-500">
              Reçu le {new Date(msg.created_at).toLocaleString()}
            </p>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default MessageInbox;

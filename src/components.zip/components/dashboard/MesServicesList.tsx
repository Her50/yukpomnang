﻿import React from 'react';

export function MesServicesList() {
  const services = [
    {
      id: 1, nom: 'Publication Immobilier', statut: 'actif', renouvelable: true,
    },
    {
      id: 2, nom: 'Analyse Marché', statut: 'expiré', renouvelable: true,
    },
  ];

  return (
    <div className="space-y-4">
      {services.map((s) => (
        <div
          key={s.id}
          className="p-4 rounded-md border shadow-sm"
        >
          <div className="font-medium">{s.nom}</div>
          <div className="text-sm text-gray-500">
            Statut : {s.statut}
          </div>
          {s.renouvelable && (
            <button className="mt-2 bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700">
              Renouveler
            </button>
          )}
        </div>
      ))}
    </div>
  );
}

export default MesServicesList;

﻿import React, { useEffect, useState } from 'react';

type Favori = {
  id: number;
  user_id: number;
  service_id: number;
  created_at: string;
};

function UserFavoris({ userId }: { userId: number }) {
  const [favoris, setFavoris] = useState<Favori[]>([]);

  useEffect(() => {
    fetch(`/api/favoris/${userId}`)
      .then((res) => res.json())
      .then((data) => setFavoris(data));
  }, [userId]);

  return (
    <div className="mt-6">
      <h2 className="text-xl font-bold mb-4">💖 Vos services favoris</h2>
      {favoris.length === 0 ? (
        <p>Aucun favori encore.</p>
      ) : (
        <ul className="space-y-2">
          {favoris.map((fav) => (
            <li
              key={fav.id}
              className="p-2 rounded border border-gray-200"
            >
              Service ID : {fav.service_id}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default UserFavoris;

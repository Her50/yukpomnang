﻿// @generated
import React from 'react';

interface Item {
  title: string;
  price: number;
  options: string[];
}

interface Props {
  category: string;
  items: Item[];
}

const CatalogueGrid: React.FC<Props> = ({ category, items }) => (
  <div>
    <h2 className="text-xl font-bold mb-4">{category}</h2>
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {items.map((item, i) => (
        <div
          key={i}
          className="border p-4 shadow rounded"
        >
          <h3 className="font-semibold">{item.title}</h3>
          <p className="text-green-700 font-bold">{item.price} FCFA</p>
          <ul className="text-sm mt-2 list-disc pl-4">
            {item.options.map((opt, j) => (
              <li key={j}>{opt}</li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  </div>
);

export default CatalogueGrid;

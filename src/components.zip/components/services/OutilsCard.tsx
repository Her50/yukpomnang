﻿// src/components/services/OutilsCard.tsx
import React from 'react';

const OutilsCard: React.FC = () => {
  return (
    <div
      style={{
        backgroundColor: '#ffffff',
        borderRadius: '12px',
        boxShadow: '0 2px 6px rgba(0,0,0,0.1)',
        padding: '24px',
        minWidth: '260px',
        maxWidth: '360px',
        flex: '1 1 30%',
        textAlign: 'center',
      }}
    >
      <div style={{ fontSize: '36px', marginBottom: '12px' }}>🛠️</div>
      <h3 style={{ fontSize: '20px', fontWeight: 600, marginBottom: '8px' }}>
        Outils Yukpomnang
      </h3>
      <p style={{ fontSize: '15px', color: '#444' }}>
        Utilisez des outils puissants : générateur de texte, prédictions, tableaux de bord, vocal et plus.
      </p>
    </div>
  );
};

export default OutilsCard;

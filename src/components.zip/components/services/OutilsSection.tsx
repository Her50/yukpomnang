﻿// src/components/services/OutilsSection.tsx
import React from 'react';

function OutilsSection() {
  return (
    <section style={{ padding: '60px 20px', maxWidth: '900px', margin: '0 auto' }}>
      <h2
        style={{
          fontSize: '26px',
          fontWeight: 'bold',
          marginBottom: '16px',
          color: '#1e1e1e',
        }}
      >
        🛠️ Outils intelligents Yukpomnang
      </h2>
      <p style={{ fontSize: '16px', color: '#555' }}>
        Explorez des outils puissants pour analyser, prédire et automatiser vos actions.
      </p>
    </section>
  );
}

export default OutilsSection;

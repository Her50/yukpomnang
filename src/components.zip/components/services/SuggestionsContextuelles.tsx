import React, { useEffect, useState } from 'react';

interface Suggestion {
  nom: string;
  plan: string;
}

const SuggestionsContextuelles: React.FC<{ serviceId: number }> = ({ serviceId }) => {
  const [related, setRelated] = useState<Suggestion[]>([]);

  useEffect(() => {
    fetch(`/api/services/${serviceId}/related`)
      .then((res) => res.json())
      .then((data) => setRelated(data));
  }, [serviceId]);

  if (!related.length) return null;

  return (
    <div className="mt-4 border-t pt-2">
      <h3 className="text-sm font-semibold mb-2">Autres services utiles :</h3>
      <ul className="list-disc ml-4 text-sm text-gray-600">
        {related.map((s, idx) => (
          <li key={idx}>
            {s.nom} ({s.plan})
          </li>
        ))}
      </ul>
    </div>
  );
};

export default SuggestionsContextuelles;

﻿// src/components/services/MatchSection.tsx
import React from 'react';

const MatchSection: React.FC = () => {
  return (
    <section style={{ padding: '60px 20px', maxWidth: '900px', margin: '0 auto' }}>
      <h2
        style={{
          fontSize: '26px',
          fontWeight: 'bold',
          marginBottom: '16px',
          color: '#1e1e1e',
        }}
      >
        🎯 Mise en relation intelligente
      </h2>
      <p style={{ fontSize: '16px', color: '#555' }}>
        Yukpomnang comprend vos besoins (texte ou vocal) et vous connecte immédiatement à la solution adaptée.
      </p>
    </section>
  );
};

export default MatchSection;

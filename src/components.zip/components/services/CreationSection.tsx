﻿// src/components/services/CreationSection.tsx
import React from 'react';

const CreationSection: React.FC = () => {
  return (
    <section style={{ padding: '60px 20px', maxWidth: '900px', margin: '0 auto' }}>
      <h2
        style={{
          fontSize: '26px',
          fontWeight: 'bold',
          marginBottom: '16px',
          color: '#1e1e1e',
        }}
      >
        🛠️ Création de service assistée
      </h2>
      <p style={{ fontSize: '16px', color: '#555' }}>
        Créez votre service en un clic avec l'aide de Yukpomnang : description, image, voix, catégorie.
      </p>
    </section>
  );
};

export default CreationSection;

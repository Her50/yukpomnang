import React from 'react';

interface PresentationServiceCardProps {
  icon: string;
  title: string;
  description: string;
  link?: string;
}

const PresentationServiceCard: React.FC<PresentationServiceCardProps> = ({
  icon, title, description, link,
}) => (
  <a
    href={link || '#'}
    style={{
      flex: '1 1 30%',
      backgroundColor: '#fff',
      borderRadius: '12px',
      boxShadow: '0 2px 6px rgba(0,0,0,0.1)',
      padding: '24px',
      minWidth: '260px',
      color: '#1a1a1a',
      textDecoration: 'none',
      transition: 'transform 0.3s ease',
    }}
    onMouseEnter={(e) => (e.currentTarget.style.transform = 'scale(1.03)')}
    onMouseLeave={(e) => (e.currentTarget.style.transform = 'scale(1.0)')}
  >
    <h3 style={{ fontSize: '22px', fontWeight: 700, marginBottom: '12px' }}>
      {icon} {title}
    </h3>
    <p style={{ fontSize: '15px', color: '#444' }}>{description}</p>
  </a>
);

export default PresentationServiceCard;

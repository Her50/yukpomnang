﻿// src/components/services/MatchCard.tsx
import React from 'react';

const MatchCard: React.FC = () => {
  return (
    <div
      style={{
        backgroundColor: '#ffffff',
        borderRadius: '12px',
        boxShadow: '0 2px 6px rgba(0,0,0,0.1)',
        padding: '24px',
        textAlign: 'center',
        flex: '1 1 30%',
        minWidth: '260px',
      }}
    >
      <h3 style={{ fontSize: '20px', fontWeight: 700, marginBottom: '12px' }}>
        🎯 Mise en relation intelligente
      </h3>
      <p style={{ fontSize: '14px', color: '#444' }}>
        Yukpomnang vous connecte à la bonne solution en un instant.
      </p>
    </div>
  );
};

export default MatchCard;

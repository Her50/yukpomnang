import { ReactNode } from 'react';
import { useUserContext } from '@/context/UserContext';

interface RequireRoleProps {
  role: Role;
  children: ReactNode;
  fallback?: ReactNode;
}

const RequireRole: React.FC<RequireRoleProps> = ({
  role,
  children,
  fallback = null,
}) => {
  const { user } = useUserContext();
  const roles: string[] = user?.roles ?? [];

  const hasRole = roles.includes(role);

  if (!user || !hasRole) {
    return <>{fallback}</>; // Peut être null ou <p>Accès refusé</p>
  }

  return <>{children}</>;
};

export default RequireRole;

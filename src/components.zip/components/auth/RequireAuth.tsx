import React from 'react';

const RequireAuth: React.FC = () => {
  return (
    <div className="p-4">
      <h2>RequireAuth</h2>
    </div>
  );
};

export default RequireAuth;

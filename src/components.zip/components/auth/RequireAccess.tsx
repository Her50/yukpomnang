import { ReactNode } from 'react';
import { useUserContext } from '@/context/UserContext';

interface RequireAccessProps {
  role?: string;
  anyOf?: string[];
  allOf?: string[];
  not?: string;
  children: ReactNode;
  fallback?: ReactNode;
}

const RequireAccess: React.FC<RequireAccessProps> = ({
  role,
  anyOf,
  allOf,
  not,
  children,
  fallback = null,
}) => {
  const { user } = useUserContext();
  const roles: string[] = user?.roles || [];

  if (!user) return <>{fallback}</>;
  if (role && !roles.includes(role)) return <>{fallback}</>;
  if (anyOf && !anyOf.some((r) => roles.includes(r))) return <>{fallback}</>;
  if (allOf && !allOf.every((r) => roles.includes(r))) return <>{fallback}</>;
  if (not && roles.includes(not)) return <>{fallback}</>;

  return <>{children}</>;
};

export default RequireAccess;

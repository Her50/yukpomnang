﻿import React from 'react';
import { useTranslation } from 'react-i18next';

const LanguageSwitcher: React.FC = () => {
  const { i18n } = useTranslation();

  const changeLanguage = (lng: string) => {
    i18n.changeLanguage(lng);
    localStorage.setItem("lng", lng); // facultatif pour persistance
  };

  return (
    <div className="flex gap-2 text-sm">
      <button onClick={() => changeLanguage('fr')} className="hover:underline">
        🇫🇷 Français
      </button>
      <button onClick={() => changeLanguage('en')} className="hover:underline">
        🇬🇧 English
      </button>
    </div>
  );
};

export default LanguageSwitcher;

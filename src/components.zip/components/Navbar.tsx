﻿// @ts-check
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import RequirePlan from '@/components/security/RequirePlan';
import logo from '@/assets/logo.png'; // ✅ Import ESM direct

function Navbar() {
  const location = useLocation();

  return (
    <nav
      style={{
        display: 'flex',
        height: '80px',
        width: '100%',
        fontFamily: "'Inter', sans-serif",
        background: '#334155',
        position: 'fixed',
        top: 0,
        left: 0,
        zIndex: 999,
        boxShadow: '0 2px 4px rgba(0,0,0,0.08)',
      }}
    >
      <div
        style={{
          background: 'white',
          width: '200px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '8px 0',
        }}
      >
        <Link to="/about" style={{ height: '100%', display: 'flex', alignItems: 'center' }}>
          <img
            src={logo}
            alt="Logo Yukpomnang"
            style={{
              height: '60px',
              width: 'auto',
              objectFit: 'contain',
            }}
          />
        </Link>
      </div>

      <div
        style={{
          flexGrow: 1,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'flex-end',
          padding: '0 40px',
          gap: '28px',
          color: '#FFFFFF',
          fontSize: '17px',
          fontWeight: 600,
        }}
      >
        <Link to="/about" style={{ textDecoration: 'none', color: 'inherit' }}>🏠 Accueil</Link>
        <Link to="/about" style={{ textDecoration: 'none', color: 'inherit' }}>ℹ️ À propos</Link>

        <select
          style={{
            background: 'white',
            color: '#1A202E',
            fontWeight: 'bold',
            borderRadius: '4px',
            padding: '6px 12px',
            cursor: 'pointer',
          }}
          onChange={(e) => {
            const path = e.target.value;
            if (path) window.location.href = path;
          }}
        >
          <option value="">📦 Nos produits</option>
          <option value="/services#match">🎯 Mise en relation</option>
          <option value="/services#creation">⚙️ Création de service</option>
          <option value="/services#outils">🛠️ Outils Yukpomnang</option>
        </select>

        <RequirePlan plan="enterprise">
          <Link to="/dashboard" style={{ textDecoration: 'none', color: 'inherit' }}>
            🤖 Yukpomnang Premium
          </Link>
        </RequirePlan>
      </div>
    </nav>
  );
}

export default Navbar;

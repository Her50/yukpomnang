﻿import React from 'react';

interface AIHelperProps {
  role?: 'admin' | 'pro' | string;
  plan?: 'pro' | string;
  context: string;
}

const AIHelper: React.FC<AIHelperProps> = ({ role, plan, context }) => {
  const help = {
    pro: {
      dashboard: '🧠 Utilisez la recherche IA pour trouver rapidement ce que vous cherchez.',
      services: '✨ Vous pouvez bénéficier d’une assistance personnalisée IA ici.',
    },
    admin: {
      dashboard: '📊 Visualisez les accès globaux selon les rôles et plans.',
    },
  };

  const tip = help?.[plan]?.[context] || help?.[role]?.[context];

  return tip ? (
    <div className="p-2 bg-blue-100 text-sm rounded-md">
      {tip}
    </div>
  ) : null;
};

export default AIHelper;

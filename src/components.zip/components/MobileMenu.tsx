﻿import React, { useState, useRef, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { useUser } from "../hooks/useUser";
import RequirePlan from "@/components/security/RequirePlan";

const MobileMenu: React.FC = () => {
  const [open, setOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const { user, logout } = useUser();
  const navigate = useNavigate();

  const toggleMenu = () => setOpen(!open);

  const handleLogout = () => {
    const confirmed = window.confirm("🔒 Voulez-vous vraiment vous déconnecter ?");
    if (confirmed) {
      logout();
      setOpen(false);
      navigate("/login", { state: { loggedOut: true } });
    }
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setOpen(false);
      }
    };
    if (open) document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [open]);

  return (
    <div className="sm:hidden relative z-50" ref={menuRef}>
      <button
        onClick={toggleMenu}
        className="p-2 text-orange-600 text-2xl"
        aria-label="Toggle menu"
      >
        ☰
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ y: -200, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -200, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="absolute top-0 left-0 w-full min-h-screen bg-white shadow-lg rounded-b-md z-50"
          >
            <div className="absolute inset-0 backdrop-blur-md bg-black/30 -z-10" />

            <nav className="flex flex-col items-start gap-4 p-4 text-gray-800">
              <Link to="/" onClick={toggleMenu}>🏠 Accueil</Link>
              <Link to="/about" onClick={toggleMenu}>📘 À propos</Link>
              <Link to="/contact" onClick={toggleMenu}>📞 Contact</Link>
              {user && (
                <Link to="/dashboard" onClick={toggleMenu}>📊 Dashboard</Link>
              )}
              <RequirePlan plan="enterprise">
                <Link to="/dashboard" onClick={toggleMenu}>🧠 Yukpomnang Premium</Link>
              </RequirePlan>
              {user && (
                <button onClick={handleLogout} className="text-red-600 hover:underline">
                  🚪 Déconnexion
                </button>
              )}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default MobileMenu;

import React, { useState } from "react";
import { ACCESS_REGISTRY, updateAccess, AccessRule } from "@/lib/accessregistry";

const AccessAuditTable: React.FC = () => {
  const [rules, setRules] = useState<AccessRule[]>([...ACCESS_REGISTRY]);

  const handleChange = (path: string, field: keyof AccessRule, value: string) => {
    const updated = rules.map(rule =>
      rule.path === path ? { ...rule, [field]: value } : rule
    );
    setRules(updated);
    const modified = updated.find(rule => rule.path === path);
    if (modified) updateAccess(modified.component, modified.role, modified.plan);
  };

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">🔐 Console des accès configurés</h2>
      <table className="w-full border text-sm">
        <thead className="bg-gray-100">
          <tr>
            <th className="border px-2 py-1">Composant</th>
            <th className="border px-2 py-1">Path</th>
            <th className="border px-2 py-1">Rôle</th>
            <th className="border px-2 py-1">Plan</th>
          </tr>
        </thead>
        <tbody>
          {rules.map(rule => (
            <tr key={rule.path} className="border-t">
              <td className="border px-2 py-1">{rule.component}</td>
              <td className="border px-2 py-1">{rule.path}</td>
              <td className="border px-2 py-1">
                <input
                  className="border rounded px-1"
                  value={rule.role}
                  onChange={(e) => handleChange(rule.path, "role", e.target.value)}
                />
              </td>
              <td className="border px-2 py-1">
                <input
                  className="border rounded px-1"
                  value={rule.plan}
                  onChange={(e) => handleChange(rule.path, "plan", e.target.value)}
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AccessAuditTable;

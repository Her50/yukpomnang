// @ts-check
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUser } from '@/hooks/useUser';

function RequireAdminPage({ children }: { children: React.ReactNode }) {
  const { user } = useUser();
  const navigate = useNavigate();
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    if (!user || user.role !== 'admin') {
      navigate('/login');
    } else {
      setChecking(false);
    }
  }, [user, navigate]);

  if (checking) {
    return <div className="text-center text-sm text-gray-500 mt-4">Vérification des droits...</div>;
  }

  return <>{children}</>;
}

export default RequireAdminPage;

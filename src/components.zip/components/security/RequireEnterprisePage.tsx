// src/hooks/useUser.ts
import { useMemo } from 'react';
import { jwtDecode } from 'jwt-decode';

export interface DecodedToken {
  id: string;
  email: string;
  role: Role;
  plan: 'free' | 'pro' | 'enterprise';
  exp: number;
}

export interface User {
  id: string;
  email: string;
  role: Role;
  plan: 'free' | 'pro' | 'enterprise';
  isAdmin: boolean;
  isUser: boolean;
}

export function useUser(): { user: User | null } {
  const user = useMemo(() => {
    const token = localStorage.getItem('token');
    if (!token) return null;

    try {
      const decoded = jwtDecode<DecodedToken>(token);
      if (decoded.exp * 1000 < Date.now()) {
        localStorage.removeItem('token');
        return null;
      }
      return {
        id: decoded.id,
        email: decoded.email,
        role: decoded.role,
        plan: decoded.plan,
        isAdmin: decoded.role === 'admin',
        isUser: decoded.role === 'user',
      };
    } catch (e) {
      console.error('Erreur décodage JWT :', e);
      return null;
    }
  }, []);

  return { user };
}

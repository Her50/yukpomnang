// src/components/security/RequirePlan.tsx
import React from "react";
import { useUser } from "@/hooks/useUser";

interface RequirePlanProps {
  plan: 'free' | 'pro' | 'enterprise';
  children: React.ReactNode;
  fallback?: React.ReactNode;
}

const RequirePlan: React.FC<RequirePlanProps> = ({ plan, children, fallback = null }) => {
  const { user } = useUser();

  if (!user || user.plan !== plan) {
    return <>{fallback}</>;
  }

  return <>{children}</>;
};

export default RequirePlan;

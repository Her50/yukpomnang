import React from "react";

const ServiceCard = () => {
  return (
    <div className="p-4">
      <h2>ServiceCard</h2>
    </div>
  );
};

export default ServiceCard;

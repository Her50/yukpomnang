// src/components/i18n/LocalizedText.tsx
import { translations } from "@/i18n/translations";
import { getUserLocale } from "@/utils/languageRouter";

interface Props {
  id: string;
}

export default function LocalizedText({ id }: Props) {
  const locale = getUserLocale();
  return <>{translations[locale]?.[id] || translations["fr"]?.[id] || id}</>;
}

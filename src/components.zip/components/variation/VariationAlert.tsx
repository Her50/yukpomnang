﻿// @generated
import React, { useState, useEffect } from 'react';
import { useServiceVariation } from '@/hooks/useServiceVariation';

const VariationAlert: React.FC<{ serviceId: number }> = ({ serviceId }) => {
  const variation = useServiceVariation(serviceId);

  if (!variation) return <p>Loading...</p>;

  return (
    <div className="p-4 border rounded-md bg-yellow-50 text-yellow-800">
      <h3 className="font-semibold mb-2">🔔 Service Variation Alert</h3>
      <p>
        💰 <strong>Prix :</strong> {variation.data.price} FCFA
      </p>
      <p>
        📦 <strong>Disponibilité :</strong>{' '}
        {variation.data.availability ? 'Disponible' : 'Indisponible'}
      </p>
      {variation.data.new && <p>🆕 Ce service est tout nouveau !</p>}
    </div>
  );
};

export default VariationAlert;

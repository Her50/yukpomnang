import React from "react";

const HeroSection: React.FC = () => {
  return (
    <div className="p-4">
      <h2>HeroSection</h2>
    </div>
  );
};

export default HeroSection;

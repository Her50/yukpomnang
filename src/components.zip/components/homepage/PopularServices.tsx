import React from "react";

const PopularServices: React.FC = () => {
  return (
    <div className="p-4">
      <h2>PopularServices</h2>
    </div>
  );
};

export default PopularServices;

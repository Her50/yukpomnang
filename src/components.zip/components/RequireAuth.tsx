import React from "react";

const RequireAuth = () => {
  return (
    <div className="p-4">
      <h2>RequireAuth</h2>
    </div>
  );
};

export default RequireAuth;

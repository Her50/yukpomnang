﻿import React from 'react';

interface CardServiceProps {
  icon: string;
  title: string;
  description: string;
}

const CardService: React.FC<CardServiceProps> = ({ icon, title, description }) => (
  <div className="bg-white shadow-md rounded-lg p-5 text-center w-full max-w-xs">
    <div className="text-3xl mb-2">{icon}</div>
    <h3 className="text-lg font-bold text-gray-800 mb-1">{title}</h3>
    <p className="text-sm text-gray-600">{description}</p>
  </div>
);

export default CardService;

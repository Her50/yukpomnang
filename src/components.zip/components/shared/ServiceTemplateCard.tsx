﻿// @generated
import React from 'react';

interface Props {
  title: string;
  variations: string[];
}

const ServiceTemplateCard: React.FC<Props> = ({ title, variations }) => (
  <div className="p-4 border rounded shadow">
    <h3 className="text-lg font-bold">{title}</h3>
    <ul className="mt-2 list-disc pl-5">
      {variations.map((v, i) => (
        <li key={i}>{v}</li>
      ))}
    </ul>
  </div>
);

export default ServiceTemplateCard;
